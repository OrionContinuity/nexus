# Living World - long gentle days (28 min sun / 12 min night)
execute store result score #day lw run time query daytime
execute if score #day lw matches ..12999 run scoreboard players add #acc lw 387
execute if score #day lw matches 13000.. run scoreboard players add #acc lw 764
execute if score #acc lw matches 1000.. run time add 1t
execute if score #acc lw matches 1000.. run scoreboard players remove #acc lw 1000
