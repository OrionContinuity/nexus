# Living World boots - take over the clock
scoreboard objectives add lw dummy
gamerule doDaylightCycle false
