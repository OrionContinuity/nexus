# Living World - long gentle days (~40 min), absolute clock
scoreboard players add #rt lw 1
execute if score #rt lw matches 2.. run function living:adv
execute store result storage living:clock Time int 1 run scoreboard players get #dt lw
function living:settime with storage living:clock
