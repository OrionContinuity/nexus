# advance our daytime by one game-tick, wrap at a full day
scoreboard players set #rt lw 0
scoreboard players add #dt lw 1
execute if score #dt lw matches 24000.. run scoreboard players set #dt lw 0
