# Living World boots - set up the clock scoreboard
scoreboard objectives add lw dummy
