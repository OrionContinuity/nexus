# Living World boots - set up the slow clock
scoreboard objectives add lw dummy
execute store result score #dt lw run time query daytime
scoreboard players set #rt lw 0
